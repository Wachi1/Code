package portfolio1;

public class portfolio5 {

	public static void main(String[] args) {
		int sum = 0;
		int number1[] = {1,2,3,4,5};
		
		for(int number : number1) {
			sum = sum + number;
		}
		System.out.println("The total of the values are: " + sum);
	}

}
