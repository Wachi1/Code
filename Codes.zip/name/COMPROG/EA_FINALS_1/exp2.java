package EA_FINALS_1;

public class exp2 {
	int a2 = 500;
	int b2 = 100;
}
