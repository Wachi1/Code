package EA_FINALS_1;

public class exp1 {
	int a1 = 100;
	int b1 = 50;
}
