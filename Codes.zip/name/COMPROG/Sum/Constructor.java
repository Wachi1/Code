package Sum;

public class Constructor {
	private int n1;
	private int n2;
	
	void setN1(int number1) {
		this.n1 = number1;
		

}
	void setN2(int number2) {
		this.n2 = number2;
		

}	
	int getN1() {
	return n1;
	
}
	int getN2() {
	return n2;
	
}
	}
