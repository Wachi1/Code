package Encapsulation;

import java.util.Scanner;

public class Sales {
	
	private double p;
	private double discRate;
	
	void setP1(double price) {
		this.p = p;


	}

	void setP2( double discRate) {
		this.discRate = discRate;
		

	}
	 double getPrice() {
		return p;
		
		
	}
	 double getDiscRate() {
		return discRate;
		
	}
	
	
	

}
