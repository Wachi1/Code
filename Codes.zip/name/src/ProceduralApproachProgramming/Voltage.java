package ProceduralApproachProgramming;

import java.util.Scanner;
public class Voltage {

	public static void main(String[] args) {
		Scanner num = new Scanner(System.in);

		int s1;
		int s2;

		System.out.println("Input your first voltage: ");
		Scanner vol = new Scanner(System.in);
		s1 = vol.nextInt();
		
		System.out.println("Input your second voltage: ");
		Scanner vol1 = new Scanner(System.in);
		s2 = vol1.nextInt();
		
		if (s1 > 5) {
			System.out.println("SWITCH 1: BREAKDOWN");}	
		if(s1 == 5) {
			 System.out.println("SWITCH 1: LED ON");
		 }
		 if(s1 != 5) {
			 System.out.println("SWITCH 1: LED OFF");
		 }
		 if(s2 > 5) {	
			 System.out.println("SWITCH 2: BREAKDOWN");
		 }
		 if (s2 == 5) {
				 System.out.println("SWITCH 2: LED ON");		 
		 }
		 if (s2 != 5) {
				 System.out.println("SWITCH 2: LED OFF");

		 
	
	
	
	
	
		 
		 
		 
		 
		 
		 
		 
	
	}
		
		
		
	}}
		
		
		
		
	

