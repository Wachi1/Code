package Problemset1;
public class Displaytextwithtabs {

	public static void main(String[] args) {

		System.out.println("One");
		System.out.println("Two\tThree");
		System.out.println("Four\tFive\tSix");
		System.out.println("Seven\tEight\tNine\tTen");

	}

}
