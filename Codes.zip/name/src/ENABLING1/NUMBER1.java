package ENABLING1;

public class NUMBER1 {

	public static void main(String[] args) {
		System.out.println("Life time is worth more than gold");

	}

}
