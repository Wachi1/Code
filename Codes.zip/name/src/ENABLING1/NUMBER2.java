package ENABLING1;

import java.util.Scanner;

public class NUMBER2 {

	public static void main(String[] args) {
	Scanner dormitory = new Scanner(System.in);
		
		double naruto = 25;
		double sasuke = 80;
		double sakura = 120;
		double rent = 225;
		

		naruto = (naruto/rent)*100;
		sasuke = (sasuke/rent)*100;
		sakura = (sakura/rent)*100;
		
		System.out.println("The contribution of Naturo in percentage is: " + naruto+ "%");
		System.out.println("The contribution of Sasuke in percentage is: " + sasuke+ "%");
		System.out.println("The contribution of Sakura in percentage is: " + sakura + "%");

		
		
		
	}


	}


